//
//  TableViewCell.swift
//  ChargeMe
//
//  Created by Jimmy Conway on 12/3/18.
//  Copyright © 2018 A290 Lab. All rights reserved.
//

import UIKit

class GroupTableViewCell: UITableViewCell {
    
    @IBOutlet weak var groupName: UILabel!
    @IBOutlet weak var membersLabel: UILabel!
    @IBOutlet weak var groupPhotoIcon: UIImageView!
    @IBOutlet weak var totalOwedLabel: UILabel!
    @IBOutlet weak var perPersonLabel: UILabel!
    

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
