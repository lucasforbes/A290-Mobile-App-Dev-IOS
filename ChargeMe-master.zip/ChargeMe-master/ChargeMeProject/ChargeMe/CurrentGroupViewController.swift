//
//  CurrentGroupViewController.swift
//  ChargeMe
//
//  Created by Jimmy Conway on 12/5/18.
//  Copyright © 2018 A290 Lab. All rights reserved.
//

import UIKit

class CurrentGroupViewController: UIViewController {
    
    var group: Group?
    var newPayments = [String]()
    var numMembers = 0.0
    var total = 0.0
    var perPerson = 0.0
    var payArray = [Double]()
    var first = 0
    var groupIndex: Int?
    
    
    @IBOutlet weak var paymentLogTextView: UITextView!
    @IBOutlet weak var owedTextView: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.title = group?.name
        var sPayLog = "" //payLog in string format
        
        for payment in (group?.payLog)! {
            sPayLog += (payment) //+ "\n")
        }
        
        paymentLogTextView.text = sPayLog
        var owed = ""
        let tot = group?.total
        let per = group?.perPerson
        total = (group?.total)!
        perPerson = (group?.perPerson)!
        let line1 = String(tot!)
        let line2 = String(per!)
        owed += "The total is $" + line1 + "\n"
        owed += "Per person that is $" + line2 + "\n\n"
        self.numMembers = Double((self.group?.members.count)!)
        // fill in local pay array with group data
        setPayArray()
        var index = 0
        for member in (self.group?.members)!{
            owed += member + " paid $" + String(self.payArray[index]) + "\n"
            index += 1
        }
        owed += "\n"
        self.perPerson = ((group?.perPerson)! * 100).rounded() / 100
        owedTextView.text = owed
        owedCalc()
        // Do any additional setup after loading the view.
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func addPayment(_ sender: Any) {
        let alertController = UIAlertController(title: "Add New Payment", message: "", preferredStyle: .alert)
        alertController.addTextField { (textField : UITextField!) -> Void in
            textField.placeholder = "Enter name of group member"
        }
        alertController.addTextField { (textField : UITextField!) -> Void in
            textField.placeholder = "Enter payment"
        }
        
        let saveAction = UIAlertAction(title: "Save", style: .default, handler: { alert -> Void in
            let firstTextField = alertController.textFields! [0] as UITextField
            let secondTextField = alertController.textFields![1] as UITextField
            let name = firstTextField.text!
            
            self.numMembers = Double((self.group?.members.count)!)
            
//            if self.first == 0{
//                self.setPayArray()
//            }
//            self.first += 1
            var addedPayment = ""
            if (self.group?.members.contains(name))! {
                // index of name
                let nameIndex = self.group?.members.index(of: name)
                
                //self.newPayments += [secondTextField.text!]
                self.total += Double(secondTextField.text!)!
                self.payArray[nameIndex!] += Double(secondTextField.text!)!
                self.perPerson = Double(round(self.total / self.numMembers * 100)/100)
                let line1 = String(self.total)
                let line2 = String(self.perPerson)
                addedPayment = (name+" paid $"+secondTextField.text!+"\n")
                self.paymentLogTextView.text = self.paymentLogTextView.text+addedPayment
                var owed = ""
                owed = "The total is $" + line1 + "\n"
                owed += "Per person is $" + line2 + "\n"
                owed += "\n"
                var index = 0
                for member in (self.group?.members)!{
                    owed += member + " paid $" + String(self.payArray[index]) + "\n"
                    index += 1
                }
                self.owedTextView.text = owed + "\n"
                self.owedCalc()
            } else {
                let noNameAlertController = UIAlertController(title: "Error", message: "Name does not appear in group", preferredStyle: .alert)
                let cancelAction = UIAlertAction(title: "Cancel", style: .default, handler: { (action : UIAlertAction!) -> Void in})
                noNameAlertController.addAction(cancelAction)
                self.present(noNameAlertController, animated: true, completion: nil)
                
            }
            if addedPayment != "" {
                self.newPayments += [addedPayment]
            }
            
        })
        let cancelAction = UIAlertAction(title: "Cancel", style: .default, handler: { (action : UIAlertAction!) -> Void in })
        
        alertController.addAction(saveAction)
        alertController.addAction(cancelAction)
        
        self.present(alertController, animated: true, completion: nil)
        
    }
    func setPayArray(){
        if((group?.payArray.count)! > 0){
            self.payArray = Array(repeating: 0.0, count: Int(self.numMembers))
            var index = 0
            // how can I access payArray?
            while index < Int(self.numMembers){
                self.payArray[index] = (group?.payArray[index])!
    
                index += 1
            }
        }
        else{
            self.payArray = Array(repeating: 0.0, count: Int(self.numMembers))
        }

    }
    
    func owedCalc() {
        var namesInOrder = Array(repeating: "", count: Int(self.numMembers))
        var index = 0
        var amountOwed = 0.0
        var owed = ""
        // create array for how much people are owed
        var need = Array(repeating: 0.0, count: Int(self.numMembers))
        var x = 0
        var y = 0
        var inOrderPayments = self.payArray
        inOrderPayments.sort(by: >)
        for payment in self.payArray{
            x = 0
            while(payment != inOrderPayments[x]){
                x += 1
            }
            namesInOrder[x] = (group?.members[y])!
            y += 1
        }
        var i = 0
        
        for member in namesInOrder{
            if inOrderPayments[i] > self.perPerson{
                need[i] = inOrderPayments[i] - self.perPerson
            }
            else{
                need[i] = 0.0
            }
            i += 1
        }
        for member in (group?.members)! {
            let paid = self.payArray[index]
            if paid >= self.perPerson {
                owed += member + " owes $0.00" + "\n"
            }
            else{
                amountOwed = self.perPerson - paid
                var ind = 0
                while amountOwed > 0.019{
                    if need[ind] > 0{
                        if need[ind] >= amountOwed{
                            //adding string to owed
                            owed += member + " owes " + (namesInOrder[ind])
                            owed += " $" + String(amountOwed) + "\n"
                            
                            need[ind] -= amountOwed
                            amountOwed = 0
                        }
                        else{
                            let dif = need[ind]
                            need[ind] -= dif
                            amountOwed -= dif
                            owed += member + " owes " + (namesInOrder[ind])
                            owed += " $" + String(dif) + "\n"
                        }
                        ind += 1
                    }
                }
            }
            index += 1
        }
        self.owedTextView.text = self.owedTextView.text + owed
    }
    
    
    
    
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        super.prepare(for: segue, sender: sender)
        group?.payLog += newPayments
        group?.payArray = self.payArray
        group?.total = self.total
        group?.perPerson = self.perPerson
     }
    
    
}

